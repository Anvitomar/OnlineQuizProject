package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Userquiz {

	@Id
	private int uqid;
	private String emailid;
	private int qzid;
	private int qid;
	private String usercorrectans;
	/**
	 * @return the uqid
	 */
	public int getUqid() {
		return uqid;
	}
	/**
	 * @param uqid the uqid to set
	 */
	public void setUqid(int uqid) {
		this.uqid = uqid;
	}
	/**
	 * @return the emailid
	 */
	public String getEmailid() {
		return emailid;
	}
	/**
	 * @param emailid the emailid to set
	 */
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	/**
	 * @return the qzid
	 */
	public int getQzid() {
		return qzid;
	}
	/**
	 * @param qzid the qzid to set
	 */
	public void setQzid(int qzid) {
		this.qzid = qzid;
	}
	/**
	 * @return the qid
	 */
	public int getQid() {
		return qid;
	}
	/**
	 * @param qid the qid to set
	 */
	public void setQid(int qid) {
		this.qid = qid;
	}
	/**
	 * @return the usercorrectans
	 */
	public String getUsercorrectans() {
		return usercorrectans;
	}
	/**
	 * @param usercorrectans the usercorrectans to set
	 */
	public void setUsercorrectans(String usercorrectans) {
		this.usercorrectans = usercorrectans;
	}
	@Override
	public String toString() {
		return "Userquiz [uqid=" + uqid + ", emailid=" + emailid + ", qzid=" + qzid + ", qid=" + qid
				+ ", usercorrectans=" + usercorrectans + "]";
	}
}